import React from "react";
import './App.css';
import AddUser from './components/Users/AddUser';
function App() {
  return (
    <div>
     <AddUser/>
    </div>
  );
}

export default App;
